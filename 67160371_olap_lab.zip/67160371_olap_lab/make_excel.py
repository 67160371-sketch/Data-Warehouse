import sqlite3
import pandas as pd
from pathlib import Path

ROOT = Path(__file__).resolve().parent
with sqlite3.connect((ROOT / 'data' / 'warehouse.db').as_uri() + '?mode=ro', uri=True) as con:
    df = pd.read_sql_query('SELECT * FROM sales', con)

# กรองเฉพาะ Drink และสร้าง Pivot Table
df_drink = df[df['category'] == 'Drink']
p_drink = df_drink.pivot_table(index='province', columns='month', values='amount', aggfunc='sum', fill_value=0, margins=True, margins_name='Total')

# เซฟเป็นไฟล์ pivot.xlsx
p_drink.to_excel(ROOT / 'pivot.xlsx')
print("สร้างไฟล์ pivot.xlsx เรียบร้อยแล้ว")