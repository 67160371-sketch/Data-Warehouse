from pathlib import Path
import sqlite3
import pandas as pd

ROOT = Path(__file__).resolve().parent

# อ่านข้อมูลจากฐานข้อมูล warehouse.db
with sqlite3.connect((ROOT / 'data' / 'warehouse.db').as_uri() + '?mode=ro', uri=True) as con:
    df = pd.read_sql_query('SELECT * FROM sales', con)

# P1: Pivot Province x Month (ต้องใส่ aggfunc='sum' เพื่อหายอดขายรวม)
print("--- P1: Pivot Province x Month ---")
p1 = df.pivot_table(
    index='province',
    columns='month',
    values='amount',
    aggfunc='sum',
    fill_value=0,
    margins=True,
    margins_name='Total'
)
print(p1)
print()

# P2: September Category x Province
print("--- P2: September Category x Province ---")
df_sep = df[df['month'] == '2026-09']
p2 = df_sep.pivot_table(
    index='category',
    columns='province',
    values='amount',
    aggfunc='sum',
    fill_value=0
)
print(p2)
print()

# P3: Assert ตรวจสอบ Grand Total
grand_total_pivot = p1.loc['Total', 'Total']
grand_total_df = df['amount'].sum()

assert grand_total_pivot == grand_total_df, f"Mismatch: {grand_total_pivot} != {grand_total_df}"
print(f"--- P3: Assert passed! Grand Total = {grand_total_pivot} ---")
print()

# P4: Export CSV
p1.to_csv(ROOT / 'pivot_province_month.csv')
p2.to_csv(ROOT / 'pivot_september.csv')
print("--- P4: Export CSV Completed ---")