SELECT 
    'fact_sales' AS source,
    COUNT(*) AS total_rows,
    SUM(quantity * unit_price) AS total_revenue
FROM fact_sales
UNION ALL
SELECT 
    'sales_view' AS source,
    COUNT(*) AS total_rows,
    SUM(amount) AS total_revenue
FROM sales;